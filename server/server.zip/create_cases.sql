PRAGMA foreign_keys=OFF;

BEGIN TRANSACTION;
INSERT INTO "cases" VALUES(1, 450, 820, 70, 50);
INSERT INTO "cases" VALUES(2,      583,
      256,
      50,
      70);
INSERT INTO "cases" VALUES(3,       583,
      185,
      50,
      70);
INSERT INTO "cases" VALUES(4,      563,
      111,
      70,
      50);
INSERT INTO "cases" VALUES(5,      494,
      111,
      70,
      50);
INSERT INTO "cases" VALUES(6,      424,
      111,
      70,
      50);
INSERT INTO "cases" VALUES(7,      397,
      287,
      50,
      70);
INSERT INTO "cases" VALUES(8,      466,
      185,
      50,
      70);
INSERT INTO "cases" VALUES(9,      511,
      185,
      50,
      70);
INSERT INTO "cases" VALUES(10,      511,
      253,
      50,
      70);
INSERT INTO "cases" VALUES(11,      465,
      253,
      50,
      70);
INSERT INTO "cases" VALUES(12,      475,
      321,
      70,
      50);
INSERT INTO "cases" VALUES(13,      396,
      357,
      50,
      70);
INSERT INTO "cases" VALUES(14,      396,
      425,
      50,
      70);
INSERT INTO "cases" VALUES(15,      396,
      495,
      50,
      70);
INSERT INTO "cases" VALUES(16,      396,
      565,
      50,
      70);
INSERT INTO "cases" VALUES(17,      396,
      635,
      50,
      70);
      INSERT INTO "cases" VALUES(18,      347,
            635,
            50,
            70);
            INSERT INTO "cases" VALUES(19,      347,
                  565,
                  50,
                  70);

                  INSERT INTO "cases" VALUES(20,      347,
                        495,
                        50,
                        70);
                        INSERT INTO "cases" VALUES(21,      347,
                              425,
                              50,
                              70);

                              INSERT INTO "cases" VALUES(22,      347,
                                    357,
                                    50,
                                    70);
                                    INSERT INTO "cases" VALUES(23,      347,
                                          288,
                                          50,
                                          70);

                                          INSERT INTO "cases" VALUES(24,      234,
                                                656,
                                                50,
                                                70);
                                                INSERT INTO "cases" VALUES(25,      234,
                                                      586,
                                                      50,
                                                      70);
                                                      INSERT INTO "cases" VALUES(26,      234,
                                                            516,
                                                            50,
                                                            70);
                                                            INSERT INTO "cases" VALUES(27,      234,
                                                                  446,
                                                                  50,
                                                                  70);
                                                                  INSERT INTO "cases" VALUES(28,      234,
                                                                        377,
                                                                        50,
                                                                        70);
                                                                        INSERT INTO "cases" VALUES(29,      234,
                                                                              309,
                                                                              50,
                                                                              70);
                                                                              INSERT INTO "cases" VALUES(30,      201,
                                                                                    261,
                                                                                    70,
                                                                                    50);
                                                                                    INSERT INTO "cases" VALUES(31,      179,
                                                                                          306,
                                                                                          50,
                                                                                          70);
                                                                                          INSERT INTO "cases" VALUES(32,      179,
                                                                                                377,
                                                                                                50,
                                                                                                70);
                                                                                                INSERT INTO "cases" VALUES(33,      179,
                                                                                                      447,
                                                                                                      50,
                                                                                                      70);
                                                                                                      INSERT INTO "cases" VALUES(34,      179,
                                                                                                            518,
                                                                                                            50,
                                                                                                            70);
                                                                                                            INSERT INTO "cases" VALUES(35,      179,
                                                                                                                  587,
                                                                                                                  50,
                                                                                                                  70);
                                                                                                                  INSERT INTO "cases" VALUES(36,      179,
                                                                                                                        657,
                                                                                                                        50,
                                                                                                                        70);
                                                                                                                        INSERT INTO "cases" VALUES(37,      83,
                                                                                                                              518,
                                                                                                                              50,
                                                                                                                              70);
                                                                                                                              INSERT INTO "cases" VALUES(38,      83,
                                                                                                                                    590,
                                                                                                                                    50,
                                                                                                                                    70);
                                                                                                                                    INSERT INTO "cases" VALUES(39,      83,
                                                                                                                                          520,
                                                                                                                                          50,
                                                                                                                                          70);
                                                                                                                                          INSERT INTO "cases" VALUES(40,      83,
                                                                                                                                                450,
                                                                                                                                                50,
                                                                                                                                                70);
                                                                                                                                                INSERT INTO "cases" VALUES(41,      83,
                                                                                                                                                      380,
                                                                                                                                                      50,
                                                                                                                                                      70);
                                                                                                                                                      INSERT INTO "cases" VALUES(42,      83,
                                                                                                                                                            311,
                                                                                                                                                            50,
                                                                                                                                                            70);
                                                                                                                                                            INSERT INTO "cases" VALUES(43,      83,
                                                                                                                                                                  240,
                                                                                                                                                                  50,
                                                                                                                                                                  70);
                                                                                                                                                                  INSERT INTO "cases" VALUES(44,      117,
                                                                                                                                                                        172,
                                                                                                                                                                        70,
                                                                                                                                                                        50);
                                                                                                                                                                        INSERT INTO "cases" VALUES(45,      185,
                                                                                                                                                                              172,
                                                                                                                                                                              70,
                                                                                                                                                                              50);
                                                                                                                                                                              INSERT INTO "cases" VALUES(46,      253,
                                                                                                                                                                                    172,
                                                                                                                                                                                    70,
                                                                                                                                                                                    50);
                                                                                                                                                                                    INSERT INTO "cases" VALUES(47,      322,
                                                                                                                                                                                          172,
                                                                                                                                                                                          70,
                                                                                                                                                                                          50);
                                                                                                                                                                                          INSERT INTO "cases" VALUES(48,      397,
                                                                                                                                                                                                759,
                                                                                                                                                                                                70,
                                                                                                                                                                                                50);


COMMIT;
